import argparse
import json
import os
import re
import hashlib
from pathlib import Path

from jobradar.application import draft
from jobradar.engine import get_by_url, save_new, score_job
from jobradar.notify import send_telegram
from jobradar.providers import collect
from jobradar.resume import load_resume_text, make_docx, resume_state, tailor_resume


ROOT = Path(__file__).resolve().parents[2]


def read_json(path):
    with path.open(encoding="utf-8") as file:
        return json.load(file)


def scan():
    sources = read_json(ROOT / "config/sources.json")
    profile = read_json(ROOT / "config/profile.json")
    raw, errors = collect(sources)
    matches = [job for item in raw if (job := score_job(item, profile))]
    added = save_new(ROOT / "data/jobs.sqlite3", matches)
    prepared = auto_prepare(matches, profile)
    for error in errors:
        print(f"Warning: {error}")
    print(f"Fetched {len(raw)} postings; {len(matches)} matched; {len(added)} new.")
    if prepared:
        print(f"Prepared {prepared} local CV review draft(s); no applications were sent.")
    if added and os.getenv("TELEGRAM_BOT_TOKEN") and os.getenv("TELEGRAM_CHAT_ID"):
        send_telegram(added)
        print("Telegram notification sent.")
    elif added:
        for job in added[:20]:
            print(f"NEW | {job['title']} | {job['company']} | {job['location']} | {job['url']}")


def auto_prepare(jobs, profile):
    if not profile.get("auto_tailor_new_matches", False) or not resume_state(ROOT):
        return 0
    try:
        source_resume = load_resume_text(ROOT)
    except ValueError as exc:
        print(f"CV preparation skipped: {exc}")
        return 0
    output = ROOT / "data/private/applications"
    output.mkdir(parents=True, exist_ok=True, mode=0o700)
    prepared = 0
    pending = []
    for job in jobs:
        key = re.sub(r"[^A-Za-z0-9_-]+", "-", job["id"]).strip("-")[:60]
        key = f"{key}-{hashlib.sha256(job['url'].encode()).hexdigest()[:8]}"
        if not ((output / f"{key}.docx").exists() and (output / f"{key}-review.md").exists()):
            pending.append((job, key))
    for job, key in pending[:10]:
        try:
            text = tailor_resume(source_resume, job)
            (output / f"{key}.docx").write_bytes(make_docx(text))
            (output / f"{key}-review.md").write_text(draft(job, profile), encoding="utf-8")
            prepared += 1
        except (RuntimeError, OSError, KeyError) as exc:
            print(f"CV draft skipped for {job.get('title', 'job')}: {exc}")
    if len(pending) > 10:
        print(f"Auto-preparation is limited to 10 jobs per scan; {len(pending) - 10} remain pending for a later scan.")
    return prepared


def main():
    parser = argparse.ArgumentParser(description="Find target-country jobs and prepare reviewed applications.")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("scan", help="Fetch configured public career boards and notify about new matches")
    prepare = commands.add_parser("prepare", help="Create a legal-disclosure review draft; does not submit")
    prepare.add_argument("url", help="Exact job URL already found by a scan")
    prepare.add_argument("--language", choices=("en", "ar"), default="en")
    web = commands.add_parser("web", help="Start the private local CV and job review page")
    web.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    if args.command == "scan":
        scan()
        return
    if args.command == "web":
        from jobradar.webapp import serve
        serve(ROOT, args.port)
        return
    job = get_by_url(ROOT / "data/jobs.sqlite3", args.url)
    if not job:
        parser.error("Job URL not found in the local scan database; run scan first.")
    output = ROOT / "outputs/applications"
    output.mkdir(parents=True, exist_ok=True)
    filename = f"application-review-{job['id'].replace(':', '-')}.md"
    path = output / filename
    path.write_text(draft(job, read_json(ROOT / "config/profile.json"), args.language), encoding="utf-8")
    print(f"Review draft saved to {path.relative_to(ROOT)}. Nothing was submitted.")


if __name__ == "__main__":
    main()
