import html
import json
import re
import sqlite3
from pathlib import Path

from jobradar.regions import target_region


def _terms(values):
    return [str(value).strip().casefold() for value in values if str(value).strip()]


def score_job(job, profile):
    title = (job.get("title") or "").casefold()
    text = f"{title} {html.unescape(job.get('description') or '')}".casefold()
    title_terms = _terms(profile.get("target_titles", []))
    skills = _terms(profile.get("skills", []))
    excludes = _terms(profile.get("exclude_terms", []))
    if not title_terms and not skills:
        return None
    if any(term in text for term in excludes):
        return None
    if title_terms and not any(term in title for term in title_terms):
        return None
    matched = sorted({term for term in skills if re.search(r"(?<!\w)" + re.escape(term) + r"(?!\w)", text)})
    score = len(matched) + (2 if title_terms else 0)
    if score < int(profile.get("minimum_score", 0)):
        return None
    job = dict(job)
    job["region"] = target_region(job.get("location", ""))
    if not job["region"]:
        return None
    job["score"] = score
    job["matched_terms"] = matched
    return job


def prepare_db(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as db:
        db.execute("""CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY, url TEXT UNIQUE NOT NULL, company TEXT, title TEXT,
            location TEXT, region TEXT, description TEXT, updated_at TEXT,
            source TEXT, score INTEGER, matched_terms TEXT, found_at TEXT DEFAULT CURRENT_TIMESTAMP
        )""")


def save_new(path, jobs):
    prepare_db(path)
    inserted = []
    with sqlite3.connect(path) as db:
        for job in jobs:
            if not job.get("id") or not job.get("url"):
                continue
            cursor = db.execute(
                "INSERT OR IGNORE INTO jobs VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)",
                (job["id"], job["url"], job["company"], job["title"], job["location"],
                 job["region"], job["description"], job["updated_at"], job["source"],
                 job["score"], json.dumps(job["matched_terms"], ensure_ascii=True)),
            )
            if cursor.rowcount:
                inserted.append(job)
    return inserted


def get_by_url(path, url):
    prepare_db(path)
    with sqlite3.connect(path) as db:
        db.row_factory = sqlite3.Row
        row = db.execute("SELECT * FROM jobs WHERE url = ?", (url,)).fetchone()
    return dict(row) if row else None


def list_jobs(path, limit=100):
    prepare_db(path)
    with sqlite3.connect(path) as db:
        db.row_factory = sqlite3.Row
        rows = db.execute(
            "SELECT * FROM jobs ORDER BY score DESC, found_at DESC LIMIT ?", (limit,)
        ).fetchall()
    result = []
    for row in rows:
        job = dict(row)
        job["matched_terms"] = json.loads(job["matched_terms"] or "[]")
        result.append(job)
    return result
