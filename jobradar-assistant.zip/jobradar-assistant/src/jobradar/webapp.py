import json
import base64
import mimetypes
from email import policy
from email.parser import BytesParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote, urlparse

from jobradar.application import draft
from jobradar.engine import get_by_url, list_jobs
from jobradar.resume import (
    MAX_TEXT_CHARS, MAX_UPLOAD_BYTES, extract_text, load_resume_text, make_docx, resume_state, save_resume,
    tailor_resume,
)


class Handler(BaseHTTPRequestHandler):
    root = None

    def _send(self, status, body, content_type="application/json; charset=utf-8", extra=None):
        data = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(data)

    def _json(self, status, data):
        self._send(status, json.dumps(data, ensure_ascii=False), extra={"Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'"})

    def _body(self, max_bytes):
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ValueError("حجم الطلب غير صالح.")
        if size < 1 or size > max_bytes:
            raise ValueError("الطلب فارغ أو أكبر من الحد المسموح.")
        return self.rfile.read(size)

    def do_GET(self):
        host = self.headers.get("Host", "").split(":", 1)[0].strip("[]").lower()
        if host not in {"127.0.0.1", "localhost"}:
            self._json(403, {"error": "التطبيق متاح على هذا الجهاز فقط."})
            return
        route = urlparse(self.path).path
        if route == "/":
            page = (self.root / "web/index.html").read_bytes()
            self._send(200, page, "text/html; charset=utf-8", {
                "Content-Security-Policy": "default-src 'self'; connect-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
            })
        elif route == "/api/status":
            state = resume_state(self.root)
            self._json(200, {"resume": state.get("filename") if state else None,
                             "jobs": len(list_jobs(self.root / "data/jobs.sqlite3"))})
        elif route == "/api/jobs":
            jobs = list_jobs(self.root / "data/jobs.sqlite3")
            self._json(200, [{key: job[key] for key in (
                "id", "url", "company", "title", "location", "region", "source",
                "score", "matched_terms", "found_at")}
                for job in jobs])
        elif route == "/api/resume/download":
            state = resume_state(self.root)
            if not state:
                self._json(404, {"error": "لم ترفع سيرة ذاتية بعد."})
                return
            path = self.root / "data/private" / state["stored_as"]
            content_type = mimetypes.guess_type(state["filename"])[0] or "application/octet-stream"
            self._send(200, path.read_bytes(), content_type, {
                "Content-Disposition": f"attachment; filename*=UTF-8''{quote(state['filename'])}"
            })
        else:
            self._json(404, {"error": "المسار غير موجود."})

    def do_POST(self):
        host = self.headers.get("Host", "").split(":", 1)[0].strip("[]").lower()
        if host not in {"127.0.0.1", "localhost"}:
            self._json(403, {"error": "التطبيق متاح على هذا الجهاز فقط."})
            return
        origin = self.headers.get("Origin")
        if origin and origin != f"http://{self.headers.get('Host', '')}":
            self._json(403, {"error": "رفض طلب من مصدر غير محلي."})
            return
        route = urlparse(self.path).path
        try:
            if route == "/api/resume":
                content_type = self.headers.get("Content-Type", "")
                body = self._body(MAX_UPLOAD_BYTES + 64 * 1024)
                message = BytesParser(policy=policy.default).parsebytes(
                    f"Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n".encode() + body
                )
                if not message.is_multipart():
                    raise ValueError("تعذر قراءة الملف المرفوع.")
                upload = next((part for part in message.iter_parts()
                               if part.get_filename()), None)
                if not upload:
                    raise ValueError("اختر ملف السيرة أولًا.")
                filename = Path(upload.get_filename()).name
                content = upload.get_payload(decode=True) or b""
                text = extract_text(filename, content)
                state = save_resume(self.root, filename, content, text)
                self._json(200, {"filename": state["filename"], "characters": len(text)})
            elif route == "/api/tailor":
                request = json.loads(self._body(64 * 1024))
                job_url = request.get("url", "")
                if not isinstance(job_url, str):
                    raise ValueError("رابط الإعلان غير صالح.")
                job = get_by_url(self.root / "data/jobs.sqlite3", job_url)
                if not job:
                    raise ValueError("لم أجد الإعلان في قاعدة الوظائف المحلية؛ أعد الفحص أولًا.")
                text = tailor_resume(load_resume_text(self.root), job)
                profile_path = self.root / "config/profile.json"
                profile = json.loads(profile_path.read_text(encoding="utf-8"))
                language = request.get("language", "en")
                if language not in {"en", "ar"}:
                    raise ValueError("لغة التصريح غير مدعومة.")
                legal = draft(job, profile, language)
                self._json(200, {"resume": text, "disclosure": legal,
                                 "title": job["title"], "company": job["company"]})
            elif route == "/api/docx":
                request = json.loads(self._body(MAX_TEXT_CHARS * 4))
                text = request.get("text", "")
                if not isinstance(text, str) or not text.strip() or len(text) > MAX_TEXT_CHARS:
                    raise ValueError("نص السيرة فارغ أو أطول من الحد المسموح.")
                self._json(200, {"docx": base64.b64encode(make_docx(text)).decode("ascii")})
            else:
                self._json(404, {"error": "المسار غير موجود."})
        except (ValueError, RuntimeError, OSError, json.JSONDecodeError) as exc:
            self._json(400, {"error": str(exc)})

    def log_message(self, fmt, *args):
        print("[JobRadar] " + fmt % args)


def serve(root, port=8765):
    Handler.root = Path(root)
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.daemon_threads = True
    print(f"JobRadar local app: http://127.0.0.1:{port} (CV stays on this computer)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Stopping JobRadar.")
    finally:
        server.server_close()
