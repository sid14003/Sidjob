"""Free, review-first job discovery assistant."""
