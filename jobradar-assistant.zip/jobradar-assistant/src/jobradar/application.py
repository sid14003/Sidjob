from datetime import datetime, timezone


def draft(job, profile, language="en"):
    key = "application_disclosure_ar" if language == "ar" else "application_disclosure_en"
    country = job.get("region") or job.get("location") or "the job location"
    disclosure = profile[key].format(country=country)
    return f"""# Application review draft

- Role: {job['title']}
- Employer: {job['company']}
- Location: {job['location']}
- Job link: {job['url']}
- Found by: {job['source']}
- Prepared: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}

## Work authorization statement ({language})

{disclosure}

## Before you submit

- Confirm that every statement above is accurate for this specific country and role.
- Confirm the employer supports sponsorship for this position.
- Review the employer's privacy notice and application form yourself.
- Attach your own CV in its original language. This tool does not upload it to the employer.
- Open the job link and submit only after your review.
"""
