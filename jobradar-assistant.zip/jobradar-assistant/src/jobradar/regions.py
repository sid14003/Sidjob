import re
import unicodedata


US_STATES = {
    "alabama", "alaska", "arizona", "arkansas", "california", "colorado", "connecticut",
    "delaware", "florida", "georgia", "hawaii", "idaho", "illinois", "indiana", "iowa",
    "kansas", "kentucky", "louisiana", "maine", "maryland", "massachusetts", "michigan",
    "minnesota", "mississippi", "missouri", "montana", "nebraska", "nevada", "new hampshire",
    "new jersey", "new mexico", "new york", "north carolina", "north dakota", "ohio", "oklahoma",
    "oregon", "pennsylvania", "rhode island", "south carolina", "south dakota", "tennessee",
    "texas", "utah", "vermont", "virginia", "washington", "west virginia", "wisconsin", "wyoming",
}

COUNTRY_ALIASES = {
    "australia": ("australia",),
    "new zealand": ("new zealand", "aotearoa"),
    "canada": ("canada",),
    "united states": ("united states", "united states of america", "usa", "u.s.a.", "u.s.", "us"),
    "mexico": ("mexico", "méxico"),
    "south america": (
        "argentina", "bolivia", "brazil", "brasil", "chile", "colombia", "ecuador",
        "french guiana", "guyane francaise", "guyana", "paraguay", "peru", "suriname", "uruguay", "venezuela",
    ),
    "germany": ("germany", "deutschland"),
    "france": ("france",),
    "spain": ("spain", "españa"),
    "portugal": ("portugal",),
    "belgium": ("belgium", "belgië", "belgique"),
    "switzerland": ("switzerland", "schweiz", "suisse"),
    "england": ("england",),
    "ireland": ("ireland",),
    "iceland": ("iceland",),
    "sweden": ("sweden",),
    "norway": ("norway",),
    "netherlands": ("netherlands", "the netherlands", "holland"),
    "austria": ("austria",),
    "poland": ("poland",),
    "lithuania": ("lithuania",),
    "latvia": ("latvia",),
    "hungary": ("hungary",),
}

US_ABBREVIATIONS = {
    "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN",
    "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV",
    "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN",
    "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY", "DC",
}


def _norm(value):
    value = unicodedata.normalize("NFKD", value.casefold())
    return "".join(ch for ch in value if not unicodedata.combining(ch))


def target_region(location):
    """Return an allowed region label, or None for ambiguous/out-of-scope locations."""
    text = _norm(location or "")
    if not text:
        return None
    if re.search(r"(?<![a-z])northern ireland(?![a-z])", text):
        return None
    parts = [part.strip() for part in re.split(r"[,|]", text) if part.strip()]
    # Broad USA labels and full state names are accepted; ambiguous two-letter
    # abbreviations only count when they are a complete location component.
    for region, aliases in COUNTRY_ALIASES.items():
        for alias in aliases:
            if re.search(r"(?<![a-z])" + re.escape(_norm(alias)) + r"(?![a-z])", text):
                return region
    for state in US_STATES:
        if re.search(r"(?<![a-z])" + re.escape(state) + r"(?![a-z])", text):
            return "united states"
    if any(part.upper() in US_ABBREVIATIONS for part in parts):
        return "united states"
    return None
