import json
import os
import urllib.parse
import urllib.request


def send_telegram(jobs):
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not jobs or not token or not chat_id:
        return False
    lines = ["JobRadar: new matching jobs"]
    for job in jobs[:15]:
        lines.extend([
            f"\n{job['title']} | {job['company']}",
            f"{job['location']} | match {job['score']}",
            job["url"],
        ])
    if len(jobs) > 15:
        lines.append(f"\nAnd {len(jobs) - 15} more; see the Actions log.")
    body = urllib.parse.urlencode({"chat_id": chat_id, "text": "\n".join(lines)}).encode()
    request = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/sendMessage", data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded"}, method="POST",
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        result = json.loads(response.read().decode())
    if not result.get("ok"):
        raise RuntimeError("Telegram rejected the notification")
    return True
