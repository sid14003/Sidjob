import json
import urllib.error
import urllib.parse
import urllib.request


TIMEOUT = 20
USER_AGENT = "JobRadarAssistant/1.0 (public career-board APIs)"


def _get_json(url):
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
        return json.loads(response.read().decode("utf-8"))


def greenhouse_jobs(source):
    board = urllib.parse.quote(source["board"], safe="-")
    payload = _get_json(f"https://boards-api.greenhouse.io/v1/boards/{board}/jobs?content=true")
    for item in payload.get("jobs", []):
        yield {
            "id": f"greenhouse:{source['board']}:{item.get('id', '')}",
            "company": source.get("company", source["board"]),
            "title": item.get("title", ""),
            "location": (item.get("location") or {}).get("name", ""),
            "url": item.get("absolute_url", ""),
            "description": item.get("content", "") or "",
            "updated_at": item.get("updated_at", ""),
            "source": "Greenhouse",
        }


def lever_jobs(source):
    site = urllib.parse.quote(source["site"], safe="-")
    host = "https://api.eu.lever.co" if source.get("region") == "eu" else "https://api.lever.co"
    payload = _get_json(f"{host}/v0/postings/{site}?mode=json")
    for item in payload if isinstance(payload, list) else []:
        categories = item.get("categories") or {}
        created = item.get("createdAt", "")
        yield {
            "id": f"lever:{source['site']}:{item.get('id', '')}",
            "company": source.get("company", source["site"]),
            "title": item.get("text", ""),
            "location": categories.get("location", ""),
            "url": item.get("hostedUrl", ""),
            "description": item.get("descriptionPlain", "") or "",
            "updated_at": str(created),
            "source": "Lever",
        }


def collect(sources):
    jobs, errors = [], []
    for provider, fetcher, key in (
        ("Greenhouse", greenhouse_jobs, "greenhouse"),
        ("Lever", lever_jobs, "lever"),
    ):
        for source in sources.get(key, []):
            if source.get("board", "").startswith("replace-") or source.get("site", "").startswith("replace-"):
                continue
            try:
                jobs.extend(fetcher(source))
            except (urllib.error.URLError, TimeoutError, ValueError, KeyError) as exc:
                errors.append(f"{provider} {source}: {exc}")
    return jobs, errors
