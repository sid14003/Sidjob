# JobRadar Assistant

A free, local-first job discovery and resume-tailoring starter. It checks configured public Greenhouse and Lever career boards, filters postings to the requested countries, deduplicates them, and can send Telegram alerts. A local web app accepts a CV and uses local Ollama to prepare a job-specific text draft. It never transmits the CV to an employer or auto-submits applications.

Read `README_AR.md` for the full Arabic setup guide, target-country list, project tree, and legal-review safeguards.

Requires Python 3.10+, Ollama, and `pip install -r requirements.txt` for PDF extraction. Configure actual company board IDs in `config/sources.json` and job titles/skills in `config/profile.json` before the first scan. GitHub Actions runs on a six-hour schedule; add Telegram credentials as repository Actions secrets, never as committed files. CV processing is local-only and the final application must be reviewed and submitted by the user.
