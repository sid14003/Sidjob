import base64
import io
import json
import http.client
import tempfile
import threading
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
from http.server import ThreadingHTTPServer

from jobradar.application import draft
from jobradar.engine import save_new, score_job
from jobradar.regions import target_region
from jobradar.resume import extract_text, make_docx, save_resume, tailor_resume
from jobradar.webapp import Handler
from jobradar.cli import auto_prepare


PROFILE = {
    "target_titles": ["security analyst"],
    "skills": ["incident response", "cctv"],
    "exclude_terms": ["unpaid"],
    "minimum_score": 2,
    "application_disclosure_en": "I need sponsorship in {country}.",
    "application_disclosure_ar": "أحتاج إلى رعاية في {country}.",
}


class RegionTests(unittest.TestCase):
    def test_allowed_countries_and_states(self):
        self.assertEqual(target_region("Melbourne, Australia"), "australia")
        self.assertEqual(target_region("Austin, TX, United States"), "united states")
        self.assertEqual(target_region("Remote, US"), "united states")
        self.assertEqual(target_region("Remote, Brazil"), "south america")
        self.assertEqual(target_region("Cayenne, French Guiana"), "south america")
        self.assertEqual(target_region("London, England"), "england")

    def test_excludes_unrequested_locations(self):
        self.assertIsNone(target_region("Dubai, UAE"))
        self.assertIsNone(target_region("London, Scotland"))
        self.assertIsNone(target_region("Belfast, Northern Ireland"))
        self.assertIsNone(target_region("Remote, worldwide"))


class MatchingTests(unittest.TestCase):
    def setUp(self):
        self.job = {
            "id": "lever:acme:42", "company": "Acme", "title": "Security Analyst",
            "location": "Toronto, Canada", "url": "https://example.org/job/42",
            "description": "Experience in incident response and CCTV operations.",
            "updated_at": "", "source": "Lever",
        }

    def test_relevance_filter(self):
        matched = score_job(self.job, PROFILE)
        self.assertEqual(matched["score"], 4)
        self.assertEqual(score_job({**self.job, "location": "Tokyo, Japan"}, PROFILE), None)
        self.assertEqual(score_job({**self.job, "description": "unpaid work"}, PROFILE), None)
        self.assertIsNone(score_job(self.job, {"minimum_score": 0}))

    def test_database_deduplicates(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "jobs.sqlite3"
            job = score_job(self.job, PROFILE)
            self.assertEqual(len(save_new(path, [job])), 1)
            self.assertEqual(len(save_new(path, [job])), 0)

    def test_application_is_review_only_and_untranslated(self):
        result = draft(score_job(self.job, PROFILE), PROFILE)
        self.assertIn("sponsorship in canada", result)
        self.assertIn("does not upload it to the employer", result)
        self.assertIn("submit only after your review", result)


class ResumeTests(unittest.TestCase):
    def test_extract_text_and_reject_unsupported_file(self):
        self.assertEqual(extract_text("cv.txt", "خبرة أمنية".encode()), "خبرة أمنية")
        with self.assertRaises(ValueError):
            extract_text("cv.exe", b"bad")

    def test_extract_docx(self):
        xml = b'''<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Security analyst</w:t></w:r></w:p></w:body></w:document>'''
        contents = io.BytesIO()
        with zipfile.ZipFile(contents, "w") as archive:
            archive.writestr("word/document.xml", xml)
        self.assertEqual(extract_text("cv.docx", contents.getvalue()), "Security analyst")

    def test_generated_docx_contains_revised_text(self):
        output = make_docx("Security experience\nخبرة أمنية")
        with zipfile.ZipFile(io.BytesIO(output)) as archive:
            document = archive.read("word/document.xml")
        self.assertIn(b"Security experience", document)
        self.assertIn("خبرة أمنية".encode(), document)
        self.assertEqual(extract_text("tailored.docx", output), "Security experience\nخبرة أمنية")

    def test_original_resume_is_kept_private(self):
        with tempfile.TemporaryDirectory() as directory:
            save_resume(directory, "my-cv.txt", b"Original CV", "Original CV")
            private = Path(directory) / "data/private"
            self.assertEqual((private / "resume-original.txt").read_bytes(), b"Original CV")
            self.assertEqual((private / "resume.txt").read_text(), "Original CV")

    def test_new_matches_are_auto_prepared_locally(self):
        job = {
            "id": "lever:acme:9", "url": "https://example.org/jobs/9", "company": "Acme",
            "title": "Security Analyst", "location": "Toronto, Canada", "region": "canada",
            "description": "Incident response", "updated_at": "", "source": "Lever",
        }
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            save_resume(root, "cv.txt", b"Security analyst", "Security analyst")
            with patch("jobradar.cli.ROOT", root), patch("jobradar.cli.tailor_resume", return_value="Security analyst tailored"):
                self.assertEqual(auto_prepare([job], {**PROFILE, "auto_tailor_new_matches": True}), 1)
            files = list((root / "data/private/applications").iterdir())
            self.assertEqual(len(files), 2)
            self.assertTrue(any(path.suffix == ".docx" for path in files))

    def test_ollama_tailoring_keeps_result_and_rejects_forbidden_word(self):
        job = {"title": "Analyst", "company": "Acme", "location": "Canada", "description": "Incident response"}
        response = io.BytesIO(json.dumps({"response": "Security experience and incident response."}).encode())
        with patch("jobradar.resume.urllib.request.urlopen", return_value=response):
            result = tailor_resume("Security experience", job)
        self.assertIn("incident response", result)
        response = io.BytesIO(json.dumps({"response": "Military security experience"}).encode())
        with patch("jobradar.resume.urllib.request.urlopen", return_value=response):
            with self.assertRaises(RuntimeError):
                tailor_resume("Security experience", job)
        with patch.dict("os.environ", {"JOBRADAR_OLLAMA_URL": "https://example.org"}):
            with self.assertRaises(RuntimeError):
                tailor_resume("Security experience", job)

    def test_local_web_upload_and_tailor_flow(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "config").mkdir()
            (root / "config/profile.json").write_text(json.dumps(PROFILE), encoding="utf-8")
            job = {
                "id": "greenhouse:acme:7", "url": "https://example.org/jobs/7",
                "company": "Acme", "title": "Security Analyst", "location": "Toronto, Canada",
                "region": "Canada", "description": "Incident response", "updated_at": "",
                "source": "Greenhouse", "score": 2, "matched_terms": ["incident response"],
            }
            from jobradar.engine import save_new
            save_new(root / "data/jobs.sqlite3", [job])
            Handler.root = root
            server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            self.addCleanup(server.server_close)
            self.addCleanup(server.shutdown)
            host, port = server.server_address
            origin = f"http://{host}:{port}"
            connection = http.client.HTTPConnection(host, port)
            self.addCleanup(connection.close)
            boundary = "----jobradar-test-boundary"
            payload = (
                f"--{boundary}\r\nContent-Disposition: form-data; name=\"resume\"; filename=\"cv.txt\"\r\n"
                "Content-Type: text/plain; charset=utf-8\r\n\r\nSecurity experience\r\n"
                f"--{boundary}--\r\n"
            ).encode()
            connection.request("POST", "/api/resume", payload, {
                "Content-Type": f"multipart/form-data; boundary={boundary}",
                "Content-Length": str(len(payload)), "Origin": origin,
            })
            response = connection.getresponse()
            self.assertEqual(response.status, 200)
            self.assertEqual(json.loads(response.read())["filename"], "cv.txt")
            self.assertEqual((root / "data/private/resume-original.txt").read_text(), "Security experience")
            generated = io.BytesIO(json.dumps({"response": "Security experience tailored for incident response."}).encode())
            with patch("jobradar.resume.urllib.request.urlopen", return_value=generated):
                body = json.dumps({"url": job["url"], "language": "en"})
                connection.request("POST", "/api/tailor", body, {
                    "Content-Type": "application/json", "Content-Length": str(len(body)), "Origin": origin,
                })
                response = connection.getresponse()
                self.assertEqual(response.status, 200)
                result = json.loads(response.read())
            self.assertIn("tailored", result["resume"])
            self.assertIn("sponsorship", result["disclosure"])
            docx_request = json.dumps({"text": result["resume"]})
            connection.request("POST", "/api/docx", docx_request, {
                "Content-Type": "application/json", "Content-Length": str(len(docx_request)), "Origin": origin,
            })
            response = connection.getresponse()
            self.assertEqual(response.status, 200)
            generated_docx = json.loads(response.read())["docx"]
            with zipfile.ZipFile(io.BytesIO(base64.b64decode(generated_docx))) as archive:
                self.assertIn("word/document.xml", archive.namelist())


if __name__ == "__main__":
    unittest.main()
